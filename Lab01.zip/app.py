from flask import Flask, request

app = Flask("lab03")
